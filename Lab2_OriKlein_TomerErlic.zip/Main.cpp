#include "Stack.h"
#include <string>
#include <iostream>
using namespace std;

int main(){
	Stack<int> s1 = Stack<int>();
	int first = 1;
	int second = 2;
	int third = 3;
	s1.push(first);
	s1.push(second);
	s1.push(third);
	while (!s1.isEmpty()){
		cout << s1.pop() << ", ";
	}
	cout << "done!\n";

	Stack<string> s2 = Stack<string>();
	string firstString = "First";
	string secondString = "Second";
	string thirdString = "Third";
	s2.push("Fourth");
	s2.push(thirdString);
	s2.push(secondString);
	s2.push(firstString);

	while (!s2.isEmpty()){
		cout << s2.pop() << ", ";
	}
	cout << "done!\n";

	Stack<double> s3 = Stack<double>();
	while (!s3.isEmpty()){
		cout << s3.pop() << ", ";
	}
	cout << "done!\n";

	system("pause");
	return 0;
}