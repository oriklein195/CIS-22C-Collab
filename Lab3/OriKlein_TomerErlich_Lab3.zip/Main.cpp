#include "InfixCalc.h"
#include <cstring>
#include <iostream>

int main(){

	InfixCalc ic1 = InfixCalc(11, "2+8/(7-2)*3");
	InfixCalc ic2 = InfixCalc(13, "(2+8)/(7-2)*3");
	InfixCalc ic3 = InfixCalc(3, "3**");
	cout << "testing \"2+8/(7-2)*3\", result should be 5\n";
	if (ic1.checkSyntax())
		cout << "The result is: " << ic1.evaluate() << endl;
	else
		cout << "Wrong syntax!\n";
	cout << "\ntesting \"(2+8)/(7-2)*3\", result should be 6\n";
	if (ic2.checkSyntax())
		cout << "The result is: " << ic2.evaluate() << endl;
	else
		cout << "Wrong syntax!\n";
	cout << "\ntesting \"3**\", result should be wrong syntax\n";
	if (ic3.checkSyntax())
		cout << "The result is: " << ic3.evaluate() << endl;
	else
		cout << "Wrong syntax!\n";
	cout << "\nYour turn:\n\n";
	int choice;
	string expression;
	InfixCalc ic;
	do{
		cout << "please choose:\n1) Test an operation\n2) Quit\n";
		cin >> choice;
		if (choice == 1){
			cout << "Please enter an expression that includes +,-,*,/,(,), no spaces and only single digit numbers: ";
			cin >> expression;
			ic = InfixCalc(expression.length(), expression);
			if (ic.checkSyntax())
				cout << "The result is: " << ic.evaluate() << endl;
			else
				cout << "Wrong syntax!\n";
		}
	} while (choice != 2);
	system("pause");
	return 0;

}