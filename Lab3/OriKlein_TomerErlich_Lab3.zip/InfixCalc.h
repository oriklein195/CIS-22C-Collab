#include "Stack.h"
#include <string>
#ifndef INFIXCALC_H
#define INFIXCALC_H

/**
A class that holds two stacks and an infix expression.
Can tell if it is syntactically correct and is able to evaluate it.
*/
class InfixCalc{
private:
	int size;
	Stack<int> operands;
	Stack<char> operators;
	string expression;
	void execute(){
		int val1, val2;
		char c;
		try {
			val2 = operands.pop();
			val1 = operands.pop();
			c = operators.pop();
		}
		catch (string s){
			throw s;
		}
		
		switch (c){
		case '+':
			operands.push(val1 + val2);
			break;
		case '-':
			operands.push(val1 - val2);
			break;
		case '*':
			operands.push(val1 * val2);
			break;
		case '/':
			if (val2 != 0)
				operands.push(val1 / val2);
			else
				throw "Can't divide by 0";
			break;
		default:
			throw "Invalid operator: '" + c + '\'';
			break;
		}
	}
	int precedence(char c){
		switch (c){
		case '(': case ')':
			return 0;
			break;
		case '+': case '-':
			return 1;
			break;
		case '*': case '/':
			return 2;
			break;
		}
	}
public:
	/*
	Instantiates a new InfixCalc object with an empty expression
	*/
	InfixCalc(){
		size = 0;
		expression = "";
		operands = Stack<int>();
		operators = Stack<char>();
	}
	/*
	Istantiates a new InfixCalc object with expression ex and size s
	NOTE: Expression must only include single digits, +, -, *, /, (, ), operands, no spaces!!
	*/
	InfixCalc(int s, string ex){
		size = s;
		expression = ex;
		operands = Stack<int>();
		operators = Stack<char>();
	}
	/*
	Assuming the expression is syntactically correct, will evaluate the result of the expression by translating it to postfix and using two stacks
	Will cause an error if dividing by 0, or is expression is syntacticaly incorrect
	*/
	int evaluate(){
		for (int i = 0; i < size; i++){
			char c = expression.at(i);
			switch (c){
			case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
				operands.push(c - '0');
				break;
			case '(':
				operators.push(c);
				break;
			case '+': case '-': case '*': case '/':
				if (operators.isEmpty())
					operators.push(c);
				else if (precedence(c) > precedence(operators.peek()))
					operators.push(c);
				else {
					while (!operators.isEmpty() && precedence(c) <= precedence(operators.peek()))
						execute();
					operators.push(c);
				}
				break;
			case ')':
				while (operators.peek() != '(')
					execute();
				operators.pop();
				break;
			}
		}
		while (!operators.isEmpty())
			execute();
		return operands.pop();
	}
	/*
	Checks if the expression is syntactially correct. 
	In order to have correct syntax it must only have single digits, operators, and paranthesis.
	Every open paranthesis should have a close parantesis, and there should not be a close paranthesis without open ones.
	Aside from paranthesis, the first charactr should be a number, and from then on an operator must come after a number and a number must follow an operator.
	*/
	bool checkSyntax(){
		int pCount = 0;
		bool nextIsVal = true;
		for (int i = 0; i < size; i++){
			char c = expression.at(i);
			switch (c){
			case '(':
				pCount++;
				break;
			case ')':
				if (pCount <= 0)
					return false;
				pCount--;
				break;
			//digits
			case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
				if (nextIsVal)
					nextIsVal = false;
				else
					return false;
				break;
			//operators
			case '+': case '-': case '*': case '/':
				if (!nextIsVal)
					nextIsVal = true;
				else
					return false;
				break;
			default:
				return false;
				break;
			}
		}
		return !(pCount || nextIsVal);

	}
};
#endif // !INFIXCALC_H
